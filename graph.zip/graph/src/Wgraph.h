#ifndef SRC_WGRAPH_H_
#define SRC_WGRAPH_H_
#include "WDigraph.h"
#include <algorithm>
#include <list>
#include <iterator>
#include <iostream>
using namespace std;

template <class T>
class Wgraph : public WDigraph<T>{
public:
	Wgraph(int theVertex = 0);
    ~Wgraph() {delete[] aList;}
    T weight(int, int);
    int numberOfVertices();
    int numberOfEdges();
    bool existsEdge(int, int);
    void insertEdge(edge<T>* theEdge);
    void eraseEdge(int, int);
    int degree(int);
    int inDegree(int);
    int outDegree(int);
    void output();
    bool dirtected()const{return false;}
    bool weighted() const{return true;}

    Wgraph Prim(int start);


protected:
    int vnumber;
    int enumber;
    typename std::list<node<T> > *aList;
};

template <class T>
Wgraph<T>::Wgraph(int theVnumber){
    if(theVnumber < 0)
        throw std::exception();
    vnumber = theVnumber;
    enumber = 0;
    aList = new list<node<T> >[vnumber+1];
}

template <class T>
T Wgraph<T>::weight(int i, int j){
	if(!this->existsEdge(i, j))
		throw std::exception();
	else{
        typename std::list<node<T> >::iterator w = aList[i].begin();
        while(w != aList[i].end()){
            if(w->vertex != j)
                ++w;
            else{
                return w->weight;
            }
        }
    }
}

template <class T>
int Wgraph<T>::numberOfVertices(){
    return vnumber;
}

template <class T>
int Wgraph<T>::numberOfEdges(){
    return enumber;
}

template <class T>
bool Wgraph<T>::existsEdge(int i, int j){
    if(i < 1 || j < 1 || i > vnumber || j > vnumber)
        throw std::exception();
    typename std::list<node<T> >::iterator xe = aList[i].begin();
    while(xe != aList[i].end()){
        if(xe->vertex != j)
            ++xe;
        else
            return true;
    }
    return false;
}

template <class T>
void Wgraph<T>::insertEdge(edge<T>* theEdge){
    int v1 = theEdge->vertex1();
    int v2 = theEdge->vertex2();
    T w = theEdge->weight();
    if(v1 < 1 || v2 < 1 || v1 > vnumber || v2 > vnumber || v1 == v2)
        throw std::exception();
    typename std::list<node<T> >::iterator ie = aList[v1].begin();
    while(ie != aList[v1].end()){
        if(ie->vertex != v2)
            ++ie;
        else
            throw std::exception();
    }
    aList[v1].push_back(node<T>(v2, w));
    aList[v2].push_back(node<T>(v1, w));
    ++enumber;
}

template <class T>
void Wgraph<T>::eraseEdge(int i, int j){
    if(i >= 1 && j >= 1 && i <= vnumber && j <= vnumber){
        typename std::list<node<T> >::iterator ee = aList[i].begin();
        while(ee != aList[i].end()){
            if(ee->vertex == j){
                aList[i].erase(ee);
                break;
            }
            else
                ++ee;
        }
        ee = aList[j].begin();
        while(ee != aList[j].end()){
            if(ee->vertex == i){
                aList[j].erase(ee);
                break;
            }
            else
                ++ee;
        }
        --enumber;
    }else
        throw std::exception();
}

template <class T>
int Wgraph<T>::degree(int){
    throw std::invalid_argument("degree() undefined");
}

template <class T>
int Wgraph<T>::inDegree(int theVertex){
    if(theVertex < 1 || theVertex > vnumber)
        throw std::exception();
    int sum = 0;
    for(int j = 1; j <= vnumber; ++j){
        typename std::list<node<T> >::iterator id = aList[j].begin();
        while(id != aList[j].end()){
            if(id->vertex == theVertex){
                ++sum;
                break;
            }
            else
                ++id;
        }
    }
    for(int i = 1; i <= vnumber; ++i){
        typename std::list<node<T> >::iterator idd = aList[i].begin();
        while(idd != aList[i].end()){
            if(idd->vertex == theVertex){
                ++sum;
                break;
            }
            else
                ++idd;
        }
    }
    return sum/2;
}

template <class T>
int Wgraph<T>::outDegree(int theVertex){
    int sum = this->inDegree(theVertex);
	return sum;
}

template <class T>
void Wgraph<T>::output(){
    for(int i = 1; i <= vnumber; ++i){
        typename std::list<node<T> >::iterator o = aList[i].begin();
        while(o != aList[i].end()){
            std::cout<<i<<"--"<<o->weight<<"--"<<o->vertex<<"   ";
            ++o;
        }
        std::cout<<endl;
    }
}

#endif /* SRC_WGRAPH_H_ */
