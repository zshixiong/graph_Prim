#ifndef SRC_WDIGRAPH_H_
#define SRC_WDIGRAPH_H_
#include "graph.h"
#include <algorithm>
#include <list>
#include <iterator>
#include <iostream>
using namespace std;

template<class T>
struct node{
    int vertex;
    T weight;
    node(int theVertex, T theWeight){
        vertex = theVertex;
        weight = theWeight;
    }
};

template <class T>
class WDigraph : public graph<T>{
public:
    WDigraph(int vnumber = 0);
    ~WDigraph() {}
    T weight(int, int)const;
    int numberOfVertices()const;
    int numberOfEdges()const;
    bool existsEdge(int, int)const;
    void insertEdge(edge<T>*);
    void eraseEdge(int, int);
    int degree(int)const;
    int inDegree(int)const;
    int outDegree(int)const;
    void output()const;
    bool directed() const{return true;}
    bool weighted() const{return true;}

    WDigraph<int> Prim(int start);
protected:
    int vnumber;
    int enumber;
    typename std::list<node<T> >* aList;
};

template <class T>
WDigraph<T>::WDigraph(int theVnumber){
    if(theVnumber < 0)
        throw std::exception();
    vnumber = theVnumber;
    enumber = 0;
    aList = new list<node<T> >[vnumber+1];
}

template <class T>
T WDigraph<T>::weight(int i, int j)const{
	if(!this->existsEdge(i, j))
		throw std::exception();
	else{
        typename std::list<node<T> >::iterator w = aList[i].begin();
        while(w != aList[i].end()){
            if(w->vertex != j)
                ++w;
            else
                return w->weight;
        }
    }
}

template <class T>
int WDigraph<T>::numberOfVertices()const{
    return vnumber;
}

template <class T>
int WDigraph<T>::numberOfEdges()const{
    return enumber;
}

template <class T>
bool WDigraph<T>::existsEdge(int i, int j)const{
    if(i < 1 || j < 1 || i > vnumber || j > vnumber)
        throw std::exception();
    typename std::list<node<T> >::iterator xe = aList[i].begin();
    while(xe != aList[i].end()){
        if(xe->vertex != j)
            ++xe;
        else
            return true;
    }
    return false;
}

template <class T>
void WDigraph<T>::insertEdge(edge<T>* theEdge){
    int v1 = theEdge->vertex1();
    int v2 = theEdge->vertex2();
    T w = theEdge->weight();
    if(v1 < 1 || v2 < 1 || v1 > vnumber || v2 > vnumber)
        throw std::exception();
    typename std::list<node<T> >::iterator ie = aList[v1].begin();
    while(ie != aList[v1].end()){
    	if(ie->vertex != v2)
    		++ie;
    	else
    		throw std::exception();
    }
    aList[v1].push_back(node<T>(v2, w));
    ++enumber;
}

template <class T>
void WDigraph<T>::eraseEdge(int i, int j){
    if(i >= 1 && j >= 1 && i <= vnumber && j <= vnumber){
        typename std::list<node<T> >::iterator ee = aList[i].begin();
        while(ee != aList[i].end()){
            if(ee->vertex == j){
                aList[i].erase(ee);
                --enumber;
                break;
            }
            else
                ++ee;
        }
    }
    else
        throw std::exception();
}

template <class T>
int WDigraph<T>::degree(int)const{
    throw std::invalid_argument("degree() undefined");
}

template <class T>
int WDigraph<T>::inDegree(int theVertex)const{
    if(theVertex < 1 || theVertex > vnumber)
        throw std::exception();
    int sum = 0;
    for(int j = 1; j <= vnumber; ++j){
    	typename std::list<node<T> >::iterator id = aList[j].begin();
        while(id != aList[j].end()){
            if(id->vertex == theVertex){
            	++sum;
            	break;
            }
            else
                ++id;
        }
    }
    return sum;
}

template <class T>
int WDigraph<T>::outDegree(int theVertex)const{
    if(theVertex < 1 || theVertex > vnumber)
        throw std::exception();
    return aList[theVertex].size();
}

template <class T>
void WDigraph<T>::output()const{
    for(int i = 1; i <= vnumber; ++i){
        typename std::list<node<T> >::iterator o = aList[i].begin();
        while(o != aList[i].end()){
        	std::cout<<i<<"---"<<o->weight<<"-->"<<o->vertex<<"   ";
            ++o;
        }
        std::cout<<endl;
    }
}

#endif /* SRC_WDIGRAPH_H_ */
