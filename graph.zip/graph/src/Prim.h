#include "WDigraph.h"
#include "Wgraph.h"
#include "weightedEdge.h"
#include <iostream>
using std::cout;
using std::endl;
#define max 100000;

template<class T>
WDigraph<int> WDigraph<T>::Prim(int start){
	 if(start < 1 || start > vnumber)
		throw std::exception();

	 cout<<"start"<<endl;

	 int n=this->vnumber;
	WDigraph<int> a(n);

	cout<<"WDigraph";

//	int weightSum = 0;
	//int index =1;
//	int index2=1;
	int i = 1;
	int prim[n+1];//用来存放双亲，数组序列表示顶点
	int weights[n+1];
//	int weight2[n+1];//用来存放最小生成树的权重，最后输出

	for(i=1; i<=n; i++){
		if(existsEdge(start, i)){
			prim[i] = start;//如果start到i存在边，则在prim[i]处存放其双亲
	  }
		else
			prim[i]=0;//0表示start到i不存在边
	}

	//weight2[index2++] = 0;

	for(i = 1; i <= n; i++){
		cout<<"i";
		//将与start顶点连接边的权重放入weights数组中，如不联通，放入最大值max
		if(existsEdge(start, i)){
			weights[i] =weight(start,i);//返回start与i边的权重
		}
		else
			weights[i] = max;   //max??? start 与  i 无连接
	}

	cout<<endl<<"i";


	for(i = 1; i < n; i++){      //有n个顶点就需要查找n-1次

		int min = max;
		int minWeightIndex = 0;
		for(int k = 1; k <= n; k++){      //寻找weights数组中的最小的权重
			if(weights[k] != 0 && weights[k] < min){   //权重等于0表示是自己指向自己的边
				min = weights[k];
				minWeightIndex = k;
			}
		}

		//prim[] = aList[minWeightIndex];  //存储图的连接链表是从1号位置存储的，而prim数组是从0号位置存储的
//		weight2[index++] = min;       //将已确定的最小权重，存储在weight2数组中，用以输出
		weights[minWeightIndex] = 0;  //已经找出来的顶点，以0作为标记

		for(int j = 1; j <= n; j++){ //
			int newWeight;
			if(existsEdge(minWeightIndex, j)){
				newWeight = weight(minWeightIndex,j);     //minWeightIndex作为顶点到其他顶点的边的权重
			}
			else
				newWeight = max;

			if(weights[j] != 0 && weights[j] > newWeight){   //若权重比weights数组中的小，则更换权重
				weights[j] = newWeight;
				prim[j]=minWeightIndex;
			}
		}





	}

	for(i=1; i <= n; i++){
		if(i == prim[i]){
			continue;
		}
		if(prim[i] != 0){
			weightedEdge<int> b(prim[i],i,weight(prim[i],i));
			a.insertEdge(&b);
		}
	}

	return a;
}

/*
//最小生成树，Prim算法
void linkedWDigraph::Prim(int start){
	int weightSum = 0;
	int index =0;
	int index2=0;
	int i = 0;
	int prim[n];
	int weights[n];
	int weight2[n];//用来存放最小生成树的权重，最后输出

	prim[index++] = aList[start];
	weight2[index2++] = 0;

	for(i = 0; i < n; i++){            //将与start顶点连接边的权重放入weights数组中，如不联通，放入最大值max
		if(existsEdge(start, i+1)){
			weights[i] =     ;//返回start与i边的权重
		}
		else
			weights[i] = max;
	}

	for(i = 0; i < n; i++){      //有n个顶点就需要查找n次
		int min = max;
		int minWeightIndex = 0;
		for(int k = 0; k < n; k++){      //寻找weights数组中的最小的权重
			if(weights[k] != 0 && weights[k] < min){   //权重等于0表示是自己指向自己的边
				min = weights[k];
				minWeightIndex = k;
			}
		}

		prim[index++] = aList[minWeightIndex + 1];  //加一是因为，存储图的连接链表是从1号位置存储的，而prim数组是从0号位置存储的
		weight2[index++] = min;       //将已确定的最小权重，存储在weight2数组中，用以输出
		weights[minWeightIndex] = 0;  //已经找出来的顶点，以0作为标记

		for(int j = 0; j < n; j++){
			int newWeight;
			if(existsEdge(minWeightIndex, j+1)){
				newWeight = ;     //minWeightIndex作为顶点到其他顶点的边的权重
			}
			else
				newWeight = max;

			if(weights[j] != 0 && weights[j] > newWeight){   //若权重比weights数组中的小，则更换权重
				weights[j] = newWeight;
			}
		}
	}
	//计算最小生成树成本
	for(i = 0; i < index; i++){
		weightSum += weight2[i];
	}

	//输出最小生成树
	cout<<"由Prim算法，从"<<start<<"顶点开始的最小生成树成本为："<<weightSum<<endl;
	cout<<"最小生成树为：";
	for(i = 0; i < index; i++){
		cout<<prim[i] <<" ";
	}
	cout<<endl;
}
*/
