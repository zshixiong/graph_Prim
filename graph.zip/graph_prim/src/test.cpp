#include "WDigraph.h"
#include "weightedEdge.h"
#include "Prim.h"
#include <iostream>
using std::cout;
using std::endl;

int main(){
	WDigraph<int> a(6);
	cout<<"number of vertices = "<<a.numberOfVertices()<<endl;
	cout<<"number of edges = "<<a.numberOfEdges()<<endl;

    weightedEdge<int> e1(1, 2, 2);
    a.insertEdge(&e1);
    cout<<a.outDegree(1)<<endl;
    weightedEdge<int> e2(1, 3, 1);
    a.insertEdge(&e2);
    cout<<a.outDegree(1)<<endl;
    weightedEdge<int> e3(1, 4, 2);
    a.insertEdge(&e3);
    cout<<a.outDegree(1)<<endl;
    weightedEdge<int> e4(1, 5, 3);
    a.insertEdge(&e4);
    cout<<a.outDegree(1)<<endl;
    weightedEdge<int> e5(1, 6, 4);
    a.insertEdge(&e5);

//
//    weightedEdge<int> e10(1, 1, 0);
//    a.insertEdge(&e10);
//    if(a.existsEdge(1, 1))
//    	cout<<"1--1 exists"<<endl;
//    else
//    	cout<<"1--1 not exists"<<endl;
//
//    cout<<"1--1 ："<<endl;
////    weight(1,1);


    cout<<a.outDegree(1)<<endl;
    cout<<"number of vertices = "<<a.numberOfVertices()<<endl;
    cout<<"number of edges = "<<a.numberOfEdges()<<endl<<endl;

    cout<<"1--6 erased, outDegree of 1 = ";
    a.eraseEdge(1, 6);
    cout<<a.outDegree(1)<<endl;
    cout<<"1--3 erased, outDegree of 1 = ";
    a.eraseEdge(1, 3);
    cout<<a.outDegree(1)<<endl;
    cout<<"number of vertices = "<<a.numberOfVertices()<<endl;
    cout<<"number of edges = "<<a.numberOfEdges()<<endl<<endl;

    if(a.existsEdge(1, 2))
    	cout<<"1--2 exists"<<endl;
    else
    	cout<<"1--2 does not exist"<<endl;
    if(a.existsEdge(1, 3))
    	cout<<"1--3 exists"<<endl;
    else
    	cout<<"1--3 does not exist"<<endl<<endl;

    weightedEdge<int> e6(3, 2, 5);
    a.insertEdge(&e6);
    cout<<"3--2 inserted, inDegree of 2 = "<<a.inDegree(2)<<endl;
    weightedEdge<int> e7(4, 2, 6);
    a.insertEdge(&e7);
    cout<<"4--2 inserted, inDegree of 2 = "<<a.inDegree(2)<<endl<<endl;

    a.output();

    WDigraph<int> b(10);
    cout<<"Prim"<<endl;
    b=a.Prim(1);
    cout<<"b"<<endl;
    b.output();
    cout<<"end"<<endl;


    return 0;
}
